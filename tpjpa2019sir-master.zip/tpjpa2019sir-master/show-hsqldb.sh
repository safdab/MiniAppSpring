#mvn dependency:copy-dependencies
java -cp target/dependency/hsqldb-2.3.4.jar org.hsqldb.util.DatabaseManager
